package edu.myrza.jibek

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JibekApplication

fun main(args: Array<String>) {
	runApplication<JibekApplication>(*args)
}
