package edu.myrza.jibek

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JibekApplicationTests {

	@Test
	fun contextLoads() {
	}

}
